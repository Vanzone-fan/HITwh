package org.health_care_system;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HealthCareSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
