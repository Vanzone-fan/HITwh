package org.health_care_system.mapper;

import org.apache.ibatis.annotations.Mapper;
import org.health_care_system.entity.TMedicine;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
* @author Administrator
* @description 针对表【t_medicine】的数据库操作Mapper
* @createDate 2024-07-29 16:02:11
* @Entity org.health_care_system.entity.TMedicine
*/
@Mapper
public interface TMedicineMapper extends BaseMapper<TMedicine> {

}




