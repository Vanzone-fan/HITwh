package org.health_care_system.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.health_care_system.entity.QueryTMedicine;
import org.health_care_system.entity.TMedicine;
import org.health_care_system.result.PageResult;
import org.health_care_system.service.TMedicineService;
import org.health_care_system.mapper.TMedicineMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
* @author Administrator
* @description 针对表【t_medicine】的数据库操作Service实现
* @createDate 2024-07-29 16:02:11
*/
@Slf4j
@Service
public class TMedicineServiceImpl extends ServiceImpl<TMedicineMapper, TMedicine> implements TMedicineService{

    @Autowired
    private TMedicineMapper tMedicineMapper;

    @Override
    public PageResult getTMedicine(int pageNum,int pageSize) {
        QueryWrapper<TMedicine> queryWrapper = new QueryWrapper<>();
        Page<TMedicine> page=Page.of(pageNum,pageSize);
        Page<TMedicine> p = tMedicineMapper.selectPage(page, queryWrapper);
        return new PageResult(p.getTotal(),p.getPages(),p.getRecords());
    }

    @Override
    public int removeByMedId(String medId) {
        QueryWrapper<TMedicine> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("med_id", medId);
        return tMedicineMapper.delete(queryWrapper);
    }

    @Override
    public void batchInsertFromExcel(MultipartFile file) {
        try (InputStream inputStream = file.getInputStream()) {
            Workbook workbook = new XSSFWorkbook(inputStream);
            Sheet sheet = workbook.getSheetAt(0); // 假设数据都在第一个sheet中
            List<TMedicine> medicines = new ArrayList<>();

            // 遍历每一行
            for (Row row : sheet) {
                if (row.getRowNum() == 0) continue; // 跳过标题行
                TMedicine medicine = new TMedicine();

                medicine.setMedId(row.getCell(0).getStringCellValue().trim());
                medicine.setMedName(row.getCell(1).getStringCellValue().trim());
                medicine.setMedExpType((int)row.getCell(2).getNumericCellValue());
                medicine.setMedExpLevel((int)row.getCell(3).getNumericCellValue());
                medicine.setMedMeasurement(row.getCell(4).getStringCellValue().trim());
                medicine.setMedMaxPrize(BigDecimal.valueOf(row.getCell(5).getNumericCellValue()));
                medicine.setMedApprovalmark((int)row.getCell(6).getNumericCellValue());
                medicine.setMedHosLevel((int)row.getCell(7).getNumericCellValue());
                medicine.setMedSize(row.getCell(8).getStringCellValue().trim());
                medicine.setMedTradename(row.getCell(9).getStringCellValue().trim());
                medicine.setMedStarttime(row.getCell(10).getLocalDateTimeCellValue());
                medicine.setMedEndtime(row.getCell(11).getLocalDateTimeCellValue());
                medicine.setMedValid((int)row.getCell(12).getNumericCellValue());
                medicine.setMedSpecialmark((int)row.getCell(13).getNumericCellValue());
                medicines.add(medicine);
            }

            // 调用批量插入方法
            saveBatch(medicines);

        } catch (IOException e) {
            log.error("Error reading the Excel file", e);
            throw new RuntimeException("Error reading the Excel file", e);
        }
    }

    @Override
    public void batchDeleteByIds(List<String> medIds) {
        for (String medId : medIds) {
            QueryWrapper<TMedicine> queryWrapper = new QueryWrapper<>();
            queryWrapper.eq("med_id", medId);
            try{
                tMedicineMapper.delete(queryWrapper);
            }catch (Exception e){
                throw new RuntimeException("Error deleting the medicine",e);
            }
        }
    }

    @Override
    public int updateByMedId(TMedicine tMedicine) {
        QueryWrapper<TMedicine> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("med_id", tMedicine.getMedId());
        return tMedicineMapper.update(tMedicine, queryWrapper);
    }

    @Override
    public PageResult getTMedicineByCondition(QueryTMedicine queryTMedicine) {
        QueryWrapper<TMedicine> queryWrapper = new QueryWrapper<>();
        if(queryTMedicine.getMedId()!=null&&!queryTMedicine.getMedId().isEmpty()){
            queryWrapper.eq("med_id",queryTMedicine.getMedId());
        }
        if (queryTMedicine.getMedName()!=null&&!queryTMedicine.getMedName().isEmpty()) {
            queryWrapper.like("med_name", queryTMedicine.getMedName());
        }
        if (queryTMedicine.getMedExpType() != null) {
            queryWrapper.eq("med_exp_type", queryTMedicine.getMedExpType());
        }
        if (queryTMedicine.getMedExpLevel() != null) {
            queryWrapper.eq("med_exp_level", queryTMedicine.getMedExpLevel());
        }
        if (queryTMedicine.getMedApprovalmark() != null) {
            queryWrapper.eq("med_approvalmark", queryTMedicine.getMedApprovalmark());
        }
        if (queryTMedicine.getMedHosLevel() != null) {
            queryWrapper.eq("med_hos_level", queryTMedicine.getMedHosLevel());
        }
        if (queryTMedicine.getMedTradename()!=null&&!queryTMedicine.getMedTradename().isEmpty()) {
            queryWrapper.like("med_tradename", queryTMedicine.getMedTradename());
        }
        if (queryTMedicine.getMedValid() != null) {
            queryWrapper.eq("med_valid", queryTMedicine.getMedValid());
        }
        if (queryTMedicine.getMedSpecialmark() != null) {
            queryWrapper.eq("med_specialmark", queryTMedicine.getMedSpecialmark());
        }
        Page<TMedicine> page=Page.of(queryTMedicine.getPageNum(),queryTMedicine.getPageSize());
        Page<TMedicine> p = tMedicineMapper.selectPage(page, queryWrapper);
        return new PageResult(p.getTotal(),p.getPages(),p.getRecords());
    }
}




