package org.health_care_system.service;

import org.health_care_system.entity.QueryTMedicine;
import org.health_care_system.entity.TMedicine;
import com.baomidou.mybatisplus.extension.service.IService;
import org.health_care_system.result.PageResult;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

/**
* @author Administrator
* @description 针对表【t_medicine】的数据库操作Service
* @createDate 2024-07-29 16:02:11
*/
public interface TMedicineService extends IService<TMedicine> {

    PageResult getTMedicine(int page,int pageSize);

    int removeByMedId(String medId);

    void batchInsertFromExcel(MultipartFile file);

    void batchDeleteByIds(List<String> medIds);

    int updateByMedId(TMedicine tMedicine);

    PageResult getTMedicineByCondition(QueryTMedicine queryTMedicine);
}
