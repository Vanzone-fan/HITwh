package org.health_care_system.controller;

import lombok.extern.slf4j.Slf4j;
import org.health_care_system.entity.QueryTMedicine;
import org.health_care_system.entity.TMedicine;
import org.health_care_system.result.PageResult;
import org.health_care_system.result.Result;
import org.health_care_system.service.TMedicineService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

/**
 * @version 1.0
 * @description: TODO
 */
@RestController
@CrossOrigin//跨域
@Slf4j
@RequestMapping("/tMedicine")
public class TMedicineController {

    @Autowired
    private TMedicineService tMedicineService;

    @GetMapping
    public PageResult getTMedicine(int pageNum,int pageSize) {
        return tMedicineService.getTMedicine(pageNum,pageSize);
    }

    @PostMapping("/query")
    public PageResult getTMedicineByCondition(@RequestBody QueryTMedicine queryTMedicine){
        return tMedicineService.getTMedicineByCondition(queryTMedicine);
    }

    @PostMapping("/save")
    public Result<String> saveTMedicine(@RequestBody TMedicine tMedicine) {
        try{
            tMedicineService.save(tMedicine);
            return Result.success("success!");
        }catch (Exception e) {
            log.error(e.getMessage());
            return Result.error(500,"failed to save");
        }
    }

    @PostMapping("/batchInsert")
    public Result<String> batchInsertFromExcel(@RequestParam("file") MultipartFile file){
        try {
            tMedicineService.batchInsertFromExcel(file);
            return Result.success("Batch insert successful!");
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            return Result.error(500,"Failed to batch insert data from Excel.");
        }
    }

    @PostMapping("/update")
    public Result<String> updateTMedicine(@RequestBody TMedicine tMedicine) {
        try{
            int r=tMedicineService.updateByMedId(tMedicine);
            if(r==1){
                return Result.success("success!");
            }else{
                return Result.error(500,"failed to update");
            }
        }catch (Exception e) {
            log.error(e.getMessage());
            return Result.error(500,"failed to update");
        }
    }

    @DeleteMapping("/delete")
    public Result<String> deleteTMedicine(String medId) {
        try{
            int r=tMedicineService.removeByMedId(medId);
            if(r==1){
                return Result.success("success!");
            }else{
                return Result.error(500,"failed to delete");
            }
        }catch (Exception e) {
            log.error(e.getMessage());
            return Result.error(500,"failed to delete");
        }
    }

    @PostMapping("/batchDelete")
    public Result<String> batchDeleteByIds(@RequestBody List<String> medIds) {
        try {
            tMedicineService.batchDeleteByIds(medIds);
            return Result.success("Batch delete successful!");
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            return Result.error(500,"Failed to batch delete by IDs.");
        }
    }
}
