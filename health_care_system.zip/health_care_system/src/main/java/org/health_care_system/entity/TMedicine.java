package org.health_care_system.entity;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Date;

/**
* 
* @TableName t_medicine
*/
@Data
@AllArgsConstructor
@NoArgsConstructor
public class TMedicine implements Serializable {

    /**
    * 药品编码
    */
    @NotBlank(message="[药品编码]不能为空")
    @Size(max= 255,message="编码长度不能超过255")
    private String medId;
    /**
    * 药品名称
    */
    @Size(max= 255,message="编码长度不能超过255")
    private String medName;
    /**
    * 收费类别
    */
    private Integer medExpType;
    /**
    * 收费项目等级
    */
    private Integer medExpLevel;
    /**
    * 药品剂量单位
    */
    @Size(max= 15,message="编码长度不能超过15")
    private String medMeasurement;
    /**
    * 最高限价
    */
    private BigDecimal medMaxPrize;
    /**
    * 是否需要审批标志
    */
    private Integer medApprovalmark;
    /**
    * 医院等级
    */
    private Integer medHosLevel;
    /**
    * 规格
    */
    @Size(max= 255,message="编码长度不能超过255")
    private String medSize;
    /**
    * 药品商品名
    */
    @Size(max= 255,message="编码长度不能超过255")
    private String medTradename;
    /**
    * 开始日期
    */
    private LocalDateTime medStarttime;
    /**
    * 终止日期
    */
    private LocalDateTime medEndtime;
    /**
    * 有效标识
    */
    private Integer medValid;
    /**
    * 特检特制标志
    */
    private Integer medSpecialmark;
}
