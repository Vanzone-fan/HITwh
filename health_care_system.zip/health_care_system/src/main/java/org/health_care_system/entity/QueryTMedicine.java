package org.health_care_system.entity;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * @version 1.0
 * @description: TODO
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class QueryTMedicine {
    private int pageNum = 1;
    private int pageSize = 10;
    /**
     * 药品编码
     */
    @Size(max= 255,message="编码长度不能超过255")
    private String medId;
    /**
     * 药品名称
     */
    @Size(max= 255,message="编码长度不能超过255")
    private String medName;
    /**
     * 收费类别
     */
    private Integer medExpType=null;
    /**
     * 收费项目等级
     */
    private Integer medExpLevel=null;
    /**
     * 是否需要审批标志
     */
    private Integer medApprovalmark=null;
    /**
     * 医院等级
     */
    private Integer medHosLevel=null;
    /**
     * 药品商品名
     */
    @Size(max= 255,message="编码长度不能超过255")
    private String medTradename;
    /**
     * 有效标识
     */
    private Integer medValid=null;
    /**
     * 特检特制标志
     */
    private Integer medSpecialmark=null;
}
