document.addEventListener('DOMContentLoaded', function () {
    /* ------------------------------------------- 函数定义 ------------------------------------------ */
    async function getMedicineData(pageNum = 1, pageSize = 10) {
        let url = `http://localhost:8081/tMedicine?pageNum=${pageNum}&pageSize=${pageSize}`;
        try {
            let response = await fetch(url);
            let res = await response.json();
            res.records.forEach(item => {
                item.medEndtime = item.medEndtime.substring(0, 19).replace('T', ' ');
            });
            return res;
        } catch (error) {
            console.error('Error:', error);
            return { records: [], pages: 0 };
        }
    }

    async function searchMedicineData(searchTerm, pageNum = 1, pageSize = 10) {
        let url = `http://localhost:8081/tMedicine/query`;
        try {
            let response = await fetch(url, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ medName: searchTerm, pageNum, pageSize }),
            });
            let res = await response.json();
            res.records.forEach(item => {
                item.medEndtime = item.medEndtime.substring(0, 19).replace('T', ' ');
            });
            return res;
        } catch (error) {
            console.error('Error:', error);
            return { records: [], pages: 0 };
        }
    }

    async function tableRender(pageNum = 1, pageSize = 10, searchTerm = '') {
        let htmlContent = ``;
        let res;
        if (searchTerm) {
            res = await searchMedicineData(searchTerm, pageNum, pageSize);
        } else {
            res = await getMedicineData(pageNum, pageSize);
        }
        let data = res.records;
        data.forEach((item, index) => {
            htmlContent += `
                <tr>
                    <td>
                        <label class="lyear-checkbox checkbox-primary">
                            <input type="checkbox" name="ids[]" value="${item.medId}" />
                            <span></span>
                        </label>
                    </td>
                    <td>${index + 1}</td>
                    <td>${item.medId}</td>
                    <td>${item.medName}</td>
                    <td>${item.medEndtime}</td>
                    <td>
                        <font class="text-success">${item.medValid == 0 ? '有效' : '无效'}</font>
                    </td>
                    <td>${item.medExpType}</td>
                    <td>${item.medExpLevel}</td>
                    <td>${item.medMaxPrize}</td>
                    <td>${item.medSpecialmark}</td>
                </tr>`;
        });
        document.querySelector('tbody').innerHTML = htmlContent;
    }

    async function initPagination(searchTerm = '') {
        let res;
        if (searchTerm) {
            res = await searchMedicineData(searchTerm);
        } else {
            res = await getMedicineData();
        }
        let pages = res.pages;
        let ul = document.querySelector('.pagination');
        ul.innerHTML = ''; // 清空现有的分页项
        ul.appendChild(createPaginationItem('«', false, true)); // Previous button
        for (let i = 1; i <= pages; i++) {
            ul.appendChild(createPaginationItem(i, i === 1, false));
        }
        ul.appendChild(createPaginationItem('»', false, false)); // Next button

        // Ensure only the first page is active initially
        ul.querySelectorAll('li').forEach((li, index) => {
            li.classList.remove('active');
            if (index === 1) {
                li.classList.add('active');
            }
        });
    }

    function createPaginationItem(content, isActive, isDisabled) {
        let li = document.createElement('li');
        if (isActive) {
            li.classList.add('active');
        }
        if (isDisabled) {
            li.classList.add('disabled');
        }
        li.innerHTML = `<span>${content}</span>`;
        return li;
    }

    function getSelectedIds() {
        let selectedIds = [];
        document.querySelectorAll('input[name="ids[]"]:checked').forEach(checkbox => {
            selectedIds.push(checkbox.value);
        });
        return selectedIds;
    }

    async function addMedicine() {
        let addbtn = document.querySelector('.add');
        if (addbtn) {
            addbtn.addEventListener('click', function () {
                window.location.href = 'medicine_add.html'; // Navigate to medicine_add.html
            });
        }
    }

    async function handleDelete() {
        let delIds = getSelectedIds();

        if (delIds.length === 0) {
            alert('请选择要删除的记录！');
            return;
        }

        try {
            let response = await fetch('http://localhost:8081/tMedicine/batchDelete', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(delIds),
            });

            if (response.ok) {
                let result = await response.json();
                alert('删除成功！');
                // 重新渲染表格
                await tableRender(); // 调用之前定义的函数重新渲染表格
                await initPagination();
                document.querySelector('ul.pagination').querySelectorAll('li').forEach((li, index) => {
                    li.classList.remove('active');
                    if (index === 1) {
                        li.classList.add('active');
                    }
                });
            } else {
                alert('删除失败！');
            }
        } catch (error) {
            console.error('删除过程中发生错误:', error);
            alert('删除过程中发生错误！');
        }
    }

    async function handleUpdate() {
        let selectedIds = getSelectedIds();

        if (selectedIds.length === 0) {
            alert('请选择要更新的记录！');
            return;
        }

        if (selectedIds.length > 1) {
            alert('只能选择一条记录进行更新！');
            return;
        }

        let updateId = selectedIds[0];
        let selectedItem = document.querySelector(`input[name="ids[]"][value="${updateId}"]`).closest('tr').children;

        let medInfo = {
            medId: selectedItem[2].textContent,
            medName: selectedItem[3].textContent,
            medEndtime: selectedItem[4].textContent,
            medValid: selectedItem[5].textContent === '有效' ? 0 : 1,
            medExpType: selectedItem[6].textContent,
            medExpLevel: selectedItem[7].textContent,
            medMaxPrize: selectedItem[8].textContent,
            medSpecialmark: selectedItem[9].textContent
        };

        localStorage.setItem('selectedMedicine', JSON.stringify(medInfo));
        window.location.href = 'medicine_update.html';
    }

    async function handlePaginationClick(event) {
        let ul = document.querySelector('ul.pagination');
        let target = event.target;

        if (target.tagName !== 'SPAN') return;

        let newIndex;
        let currentIndex = Array.from(ul.querySelectorAll('li')).findIndex(li => li.classList.contains('active')) - 1;

        if (target.textContent == '«') {
            newIndex = currentIndex - 1;
        } else if (target.textContent == '»') {
            newIndex = currentIndex + 1;
        } else {
            newIndex = parseInt(target.textContent);
        }

        if (newIndex >= 1 && newIndex <= ul.childElementCount - 2) {
            // Adjust for « and » buttons
            await tableRender(newIndex);

            // Update active class
            ul.querySelectorAll('li').forEach((li, index) => {
                li.classList.remove('active');
                if (index === newIndex + 1) {
                    li.classList.add('active');
                }
            });

            // Enable/Disable « and » buttons
            ul.querySelector('li:first-child').classList.toggle('disabled', newIndex === 1);
            ul.querySelector('li:last-child').classList.toggle('disabled', newIndex === ul.childElementCount - 3);
        }
    }

    async function handleSearchInput() {
        let searchInput = document.getElementById('search-input');
        if (searchInput) {
            searchInput.addEventListener('input', async function () {
                console.log('搜索内容:', searchInput.value);
                await tableRender(1, 10, searchInput.value);
                await initPagination(searchInput.value);
            });
        }
    }

    async function addBulk() {
        let addBulkBtn = document.querySelector('.add-bulk');
        if (addBulkBtn) {
            addBulkBtn.addEventListener('click', function () {
                window.location.href = 'file_upload.html'; // Navigate to file_upload.html
            });
        }
    }

    /* ------------------------------------------- 函数执行 ------------------------------------------ */
    (async function () {
        await tableRender();
        await initPagination();
        await addMedicine();
        await handleSearchInput();
        await addBulk(); // 添加这一行
    })();

    document.querySelector('.delete-mul').addEventListener('click', handleDelete);
    document.querySelector('.update').addEventListener('click', handleUpdate);
    document.querySelector('ul.pagination').addEventListener('click', handlePaginationClick);
});
